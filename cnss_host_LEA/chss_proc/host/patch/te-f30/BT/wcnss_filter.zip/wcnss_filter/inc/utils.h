/*==========================================================================
Description
   Header function for declarations of platform related utils

# Copyright (c) 2016 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.

===========================================================================*/


#ifndef _UTILS_H_
#define _UTILS_H_


#ifndef ANDROID
#include <linux/ioctl.h>
#include <sys/types.h>
#include "comdef.h"

#define ANT_SOCK "/etc/bluetooth/ant_sock"
#define CTRL_SOCK "/etc/bluetooth/wcnssfilter_ctrl"
#define BT_SOCK "/etc/bluetooth/bt_sock"
#define FM_SOCK "/etc/bluetooth/fm_sock"
#define SOCKETNAME  "/etc/bluetooth/btprop"

int bt_property_init(void);
int property_get_bt(const char *key, char *value, const char *default_value);
int property_set_bt(const char *key, const char *value);


#define ANDROID_RESERVED_SOCKET_PREFIX "/dev/socket/"
#define BOTHER 0010000

#if !defined(NCCS)
#define NCCS 19
#endif /* NCCS */

struct termios2 {
        unsigned short c_iflag;               /* input mode flags */
        unsigned short c_oflag;               /* output mode flags */
        unsigned short c_cflag;               /* control mode flags */
        unsigned short c_lflag;               /* local mode flags */
        unsigned short c_line;                    /* line discipline */
        unsigned short c_cc[NCCS];                /* control characters */
        unsigned short c_ispeed;               /* input speed */
        unsigned short c_ospeed;               /* output speed */
};

#if !defined(TCGETS2)
#define TCGETS2         _IOR('T',0x2A, struct termios2)
#define TCSETS2         _IOW('T',0x2B, struct termios2)
#define TCSETSW2        _IOW('T', 0x2C, struct termios2)
#endif /* TCGETS2 */

#define TIOCM_LE 0x001
#define TIOCM_DTR 0x002
#define TIOCM_RTS 0x004
#define TIOCM_ST 0x008
#define TIOCM_SR 0x010
#define TIOCM_CTS 0x020
#define TIOCM_CAR 0x040
#define TIOCM_RNG 0x080
#define TIOCM_DSR 0x100
#define TIOCM_CD TIOCM_CAR
#define TIOCM_RI TIOCM_RNG
#define TIOCM_OUT1 0x2000
#define TIOCM_OUT2 0x4000
#define TIOCM_LOOP 0x8000

/*TODO verify values with android build*/
#define TIOCMGET  0x5415
#define TIOCMSET  0x5418

// Linux "abstract" (non-filesystem) namespace
#define ANDROID_SOCKET_NAMESPACE_ABSTRACT 0
// Android "reserved" (/dev/socket) namespace
#define ANDROID_SOCKET_NAMESPACE_RESERVED 1
// Normal filesystem namespace
#define ANDROID_SOCKET_NAMESPACE_FILESYSTEM 2

struct ucred {
  pid_t pid;
  uid_t uid;
  gid_t gid;
};
#endif

typedef enum {
    BT_SOC_DEFAULT = 0,
    BT_SOC_SMD = BT_SOC_DEFAULT,
    BT_SOC_AR3K,
    BT_SOC_ROME,
    BT_SOC_CHEROKEE,
    /* Add chipset type here */
    BT_SOC_RESERVED
}bt_soc_type;

int get_bt_soc_type();

#endif//_UTILS_H_
