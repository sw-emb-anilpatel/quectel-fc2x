/*==========================================================================
Description
   Header function for definition of platform related utils

# Copyright (c) 2016 Qualcomm Technologies, Inc.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.

===========================================================================*/


#ifdef ANDROID
#include <cutils/log.h>
#include <cutils/properties.h>
#endif

#include <strings.h>
#include "utils.h"

#define LOG_TAG "WCNSS_FILTER/utils.c"

#ifndef ANDROID
#include <sys/socket.h>
#include <sys/un.h>
#include <stddef.h>
#include "bt_linux_log.h"

static int bt_prop_socket;      /* This end of connection*/
struct sockaddr_un un_sock_name;
/*
 * strlcpy - like strcpy/strncpy, doesn't overflow destination buffer,
 * always leaves destination null-terminated (for len > 0).
 */
size_t strlcpy( char *dest, const char *src, size_t len)
{
    size_t ret = strlen(src);

    if (len != 0) {
    if (ret < len)
        strcpy(dest, src);
    else {
        strncpy(dest, src, len - 1);
        dest[len-1] = 0;
    }
    }
    return ret;
}

int bt_property_init(void)
{
    int len;    /* length of sockaddr */
    struct sockaddr_un name;
    if( (bt_prop_socket = socket(AF_UNIX, SOCK_STREAM, 0) ) < 0) {
      perror("socket");
        ALOGI("bt_property_init: exit %d", bt_prop_socket);
      exit(1);
    }
        ALOGI("bt_property_init: bt_prop_socket %d", bt_prop_socket);

    /*Create the address of the server.*/
    memset(&name, 0, sizeof(struct sockaddr_un));
    name.sun_family = AF_UNIX;
    strlcpy(name.sun_path, SOCKETNAME, sizeof(name.sun_path));
    //ALOGE("connecting to %s, fd = %d", SOCKETNAME, bt_prop_socket);
    len = sizeof(name.sun_family) + strlen(name.sun_path);
    /*Connect to the server.*/
    if (connect(bt_prop_socket, (struct sockaddr *) &name, len) < 0){
        perror("connect");

        exit(1);
    }
}

int property_get_bt(const char *key, char *value, const char *default_value)
{
#if 0
    char prop_string[200] = {'\0'};
    int ret, bytes_read = 0, i = 0;

    snprintf(prop_string, sizeof(prop_string), "get_property %s,", key);
    ret = send(bt_prop_socket, prop_string, strlen(prop_string), 0);
    memset(value, 0, sizeof(value));
    do
    {
        bytes_read = recv(bt_prop_socket, &value[i], 1, 0);
        if (bytes_read == 1)
        {
            if (value[i] == ',')
            {
                value[i] = '\0';
                break;
            }
            i++;
        }
    } while(1);
    ALOGV("property_get_bt: key(%s) has value: %s", key, value);
    if (!i && default_value)
    {
        ALOGV("property_get_bt: Copied default =%s", default_value);
        strncpy(value, default_value, strlen(default_value)+1);
        return 1;
    }
#endif
    return 0;
}

/* property_set_bt: returns 0 on success, < 0 on failure
*/
int property_set_bt(const char *key, const char *value)
{
#if 0
    char prop_string[200] = {'\0'};
    int ret;
    snprintf(prop_string, sizeof(prop_string), "set_property %s %s,", key, value);
    ALOGV("property_set_bt: setting key(%s) to value: %s\n", key, value);
    ret = send(bt_prop_socket, prop_string, strlen(prop_string), 0);
#endif
    return 0;
}

/*
 * strlcat - like strcat/strncat, doesn't overflow destination buffer,
 * always leaves destination null-terminated (for len > 0).
 */
size_t strlcat(char *dest, const char *src, size_t len)
{
    size_t dlen = strlen(dest);

    return dlen + strlcpy(dest + dlen, src, (len > dlen? len - dlen: 0));
}

int socket_make_sockaddr_un(const char *name, int namespaceId, 
        struct sockaddr_un *p_addr, socklen_t *alen)
{
    memset (p_addr, 0, sizeof (*p_addr));
    size_t namelen;

    switch (namespaceId) {
        case ANDROID_SOCKET_NAMESPACE_ABSTRACT:
            namelen  = strlen(name);

            // Test with length +1 for the *initial* '\0'.
            if ((namelen + 1) > sizeof(p_addr->sun_path)) {
                goto error;
            }

            /*
             * Note: The path in this case is *not* supposed to be
             * '\0'-terminated. ("man 7 unix" for the gory details.)
             */
            
            p_addr->sun_path[0] = 0;
            memcpy(p_addr->sun_path + 1, name, namelen);
        break;

        case ANDROID_SOCKET_NAMESPACE_RESERVED:
            namelen = strlen(name) + strlen(ANDROID_RESERVED_SOCKET_PREFIX);
            /* unix_path_max appears to be missing on linux */
            if (namelen > sizeof(*p_addr) 
                    - offsetof(struct sockaddr_un, sun_path) - 1) {
                goto error;
            }

            strcpy(p_addr->sun_path, ANDROID_RESERVED_SOCKET_PREFIX);
            strcat(p_addr->sun_path, name);
        break;

        case ANDROID_SOCKET_NAMESPACE_FILESYSTEM:
            namelen = strlen(name);
            /* unix_path_max appears to be missing on linux */
            if (namelen > sizeof(*p_addr) 
                    - offsetof(struct sockaddr_un, sun_path) - 1) {
                goto error;
            }

            strcpy(p_addr->sun_path, name);
        break;
        default:
            // invalid namespace id
            return -1;
    }

    p_addr->sun_family = AF_LOCAL;
    *alen = namelen + offsetof(struct sockaddr_un, sun_path) + 1;
    return 0;
error:
    return -1;
}

/**
 * Binds a pre-created socket(AF_LOCAL) 's' to 'name'
 * returns 's' on success, -1 on fail
 *
 * Does not call listen()
 */
int socket_local_server_bind(int s, const char *name, int namespaceId)
{
    struct sockaddr_un addr;
    socklen_t alen;
    int n;
    int err;

    err = socket_make_sockaddr_un(name, namespaceId, &addr, &alen);

    if (err < 0) {
        return -1;
    }

    /* basically: if this is a filesystem path, unlink first */
#if !defined(__linux__)
    if (1) {
#else
    if (namespaceId == ANDROID_SOCKET_NAMESPACE_RESERVED
        || namespaceId == ANDROID_SOCKET_NAMESPACE_FILESYSTEM) {
#endif
        /*ignore ENOENT*/
        unlink(addr.sun_path);
    }

    n = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &n, sizeof(n));

    if(bind(s, (struct sockaddr *) &addr, alen) < 0) {
        return -1;
    }

    return s;
}

#endif

/** Get Bluetooth SoC type from system setting */
int get_bt_soc_type()
{
    int ret = 0;
    char bt_soc_type[PROPERTY_VALUE_MAX];

    ALOGI("bt-vendor : get_bt_soc_type");

#ifdef ANDROID
    ret = property_get("qcom.bluetooth.soc", bt_soc_type, NULL);
#else
    //ret = property_get_bt("qcom.bluetooth.soc", bt_soc_type, NULL);
#endif
    if (ret != 0) {
        ALOGI( "qcom.bluetooth.soc set to %s\n", bt_soc_type);
        if (!strncasecmp(bt_soc_type, "rome", sizeof("rome"))) {
            return BT_SOC_ROME;
        }
        else if (!strncasecmp(bt_soc_type, "cherokee", sizeof("cherokee"))) {
            return BT_SOC_CHEROKEE;
        }
        else {
            ALOGI( "qcom.bluetooth.soc not set, so using default.\n");
            return BT_SOC_DEFAULT;
        }
    }
    else
    {
        ALOGE( "%s: Failed to get soc type", __FUNCTION__);
#ifdef ANDROID
        ret = BT_SOC_DEFAULT;
#else
		/*TODO: Fic property issue*/
        ret = BT_SOC_ROME;
#endif
    }

    return ret;
}

